#!/data/data/com.termux/files/usr/bin/bash
echo "Este script limpia la caché de descargas de apt."
echo "No elimina tus documentos personales."
read -r -p "¿Limpiar caché ahora? [s/N] " answer
case "$answer" in s|S|si|SI|sí|Sí) apt clean && echo "Caché limpiada." ;; *) echo "Cancelado." ;; esac
