#!/data/data/com.termux/files/usr/bin/bash
read -r -p "Duración en segundos (1-86400): " seconds
case "$seconds" in ''|*[!0-9]*) echo "Introduce un número entero."; exit 1 ;; esac
[ "$seconds" -ge 1 ] && [ "$seconds" -le 86400 ] || { echo "Fuera de rango."; exit 1; }
echo "Temporizador iniciado por $seconds segundos."
sleep "$seconds"
printf '\a'
echo "¡Tiempo terminado!"
