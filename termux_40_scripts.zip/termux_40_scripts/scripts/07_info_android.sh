#!/data/data/com.termux/files/usr/bin/bash
echo "=== INFORMACION DEL SISTEMA ==="
for key in ro.build.version.release ro.build.version.sdk ro.product.manufacturer ro.product.model; do
  printf '%s: ' "$key"
  if command -v getprop >/dev/null 2>&1; then getprop "$key"; else echo "getprop no disponible"; fi
done
