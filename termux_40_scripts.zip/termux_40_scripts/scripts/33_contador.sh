#!/data/data/com.termux/files/usr/bin/bash
read -r -p "¿Hasta qué número contar? (1-1000): " limit
case "$limit" in ''|*[!0-9]*) echo "Introduce un entero."; exit 1 ;; esac
[ "$limit" -ge 1 ] && [ "$limit" -le 1000 ] || { echo "El rango permitido es 1-1000."; exit 1; }
for ((i=1; i<=limit; i++)); do printf '%s ' "$i"; done
echo
