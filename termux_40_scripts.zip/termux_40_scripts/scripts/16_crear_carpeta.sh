#!/data/data/com.termux/files/usr/bin/bash
read -r -p "Nombre de carpeta (se creará dentro de HOME): " name
case "$name" in ""|*/*|.|..) echo "Nombre no válido."; exit 1 ;; esac
mkdir -p "$HOME/$name" && echo "Carpeta creada: $HOME/$name"
