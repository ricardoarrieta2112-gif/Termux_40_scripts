#!/data/data/com.termux/files/usr/bin/bash
set -u
for url in https://example.com https://www.google.com; do
  printf '%s: ' "$url"
  if curl -LIs --connect-timeout 4 --max-time 8 "$url" >/dev/null 2>&1; then echo "OK"; else echo "sin respuesta"; fi
done
