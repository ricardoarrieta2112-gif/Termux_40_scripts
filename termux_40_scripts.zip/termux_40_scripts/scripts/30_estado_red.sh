#!/data/data/com.termux/files/usr/bin/bash
echo "=== ESTADO BASICO DE RED ==="
printf 'DNS configurado (si visible):\n'
cat "$PREFIX/etc/resolv.conf" 2>/dev/null || echo "No se pudo leer resolv.conf"
echo
printf 'Prueba HTTPS: '
if command -v curl >/dev/null 2>&1 && curl -Is --connect-timeout 4 --max-time 7 https://example.com >/dev/null 2>&1; then echo "OK"; else echo "No confirmada"; fi
