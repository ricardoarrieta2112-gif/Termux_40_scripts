#!/data/data/com.termux/files/usr/bin/bash
read -r -p "Ruta del archivo de origen: " src
[ -f "$src" ] || { echo "No existe un archivo en esa ruta."; exit 1; }
read -r -p "Carpeta de destino (dentro de HOME): " dest
case "$dest" in ""|/*|../*|*/../*) echo "Usa una carpeta relativa dentro de HOME."; exit 1 ;; esac
mkdir -p "$HOME/$dest" && cp -i -- "$src" "$HOME/$dest/" && echo "Copia completada."
