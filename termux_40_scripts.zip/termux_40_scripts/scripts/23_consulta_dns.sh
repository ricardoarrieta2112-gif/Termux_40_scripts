#!/data/data/com.termux/files/usr/bin/bash
read -r -p "Dominio (ej. example.com): " domain
[ -n "$domain" ] || exit 1
if command -v nslookup >/dev/null 2>&1; then nslookup "$domain"
elif command -v getent >/dev/null 2>&1; then getent hosts "$domain"
else echo "Instala dnsutils: pkg install dnsutils"; fi
