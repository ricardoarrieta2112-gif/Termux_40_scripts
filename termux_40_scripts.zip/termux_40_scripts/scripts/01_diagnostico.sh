#!/data/data/com.termux/files/usr/bin/bash
set -u
echo "=== DIAGNOSTICO TERMUX ==="
date
printf 'Android/kernel: '; uname -sr
printf 'Arquitectura: '; uname -m
printf 'HOME: %s\nPREFIX: %s\n' "$HOME" "${PREFIX:-desconocido}"
echo
echo "-- Espacio en HOME --"; df -h "$HOME"
echo
echo "-- Memoria visible --"
if [ -r /proc/meminfo ]; then grep -E '^(MemTotal|MemAvailable|SwapTotal|SwapFree):' /proc/meminfo; else echo "No disponible"; fi
echo
if command -v curl >/dev/null 2>&1; then
  if curl -Is --connect-timeout 4 --max-time 7 https://example.com >/dev/null 2>&1; then echo "Internet HTTPS: disponible"; else echo "Internet HTTPS: no comprobado"; fi
else echo "Instala curl para probar HTTPS: pkg install curl"; fi
