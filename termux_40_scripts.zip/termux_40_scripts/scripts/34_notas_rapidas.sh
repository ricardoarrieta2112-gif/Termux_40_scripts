#!/data/data/com.termux/files/usr/bin/bash
file="$HOME/notas_termux.txt"
echo "Escribe una nota. Línea vacía para cancelar."
read -r -p "> " note
[ -n "$note" ] || { echo "No se guardó ninguna nota."; exit 0; }
printf '[%s] %s\n' "$(date '+%F %T')" "$note" >> "$file"
echo "Nota guardada en $file"
