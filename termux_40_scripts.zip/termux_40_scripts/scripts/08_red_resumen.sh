#!/data/data/com.termux/files/usr/bin/bash
echo "=== INTERFACES DE RED ==="
if command -v ip >/dev/null 2>&1; then ip addr show 2>/dev/null | grep -E '^[0-9]+:|inet ' || true
else echo "Comando ip no disponible."; fi
echo
echo "Direcciones pueden ocultarse o limitarse según Android."
