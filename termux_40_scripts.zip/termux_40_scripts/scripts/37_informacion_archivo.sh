#!/data/data/com.termux/files/usr/bin/bash
read -r -p "Ruta del archivo o carpeta: " path
[ -e "$path" ] || { echo "No existe."; exit 1; }
ls -ldh -- "$path"
if [ -f "$path" ]; then
  wc -lc -- "$path"
  command -v file >/dev/null 2>&1 && file -- "$path"
fi
