#!/data/data/com.termux/files/usr/bin/bash
echo "Consultará un servicio externo para detectar la IP pública."
echo "No muestra necesariamente la IP local de tu tablet."
if command -v curl >/dev/null 2>&1; then curl -fsS --connect-timeout 5 --max-time 8 https://api.ipify.org && echo; else echo "Instala curl: pkg install curl"; fi
