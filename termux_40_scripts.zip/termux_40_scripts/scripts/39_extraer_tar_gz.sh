#!/data/data/com.termux/files/usr/bin/bash
read -r -p "Ruta del archivo .tar.gz: " archive
[ -f "$archive" ] || { echo "Archivo no encontrado."; exit 1; }
case "$archive" in *.tar.gz|*.tgz) ;; *) echo "El archivo no parece .tar.gz/.tgz."; exit 1 ;; esac
dest="$HOME/extraido_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$dest" || exit 1
echo "Se extraerá en $dest"
tar -tzf "$archive" >/dev/null 2>&1 || { echo "Archivo comprimido inválido."; rmdir "$dest"; exit 1; }
tar -xzf "$archive" -C "$dest" && echo "Extracción terminada."
