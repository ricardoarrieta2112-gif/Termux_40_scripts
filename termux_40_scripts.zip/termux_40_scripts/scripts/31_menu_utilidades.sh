#!/data/data/com.termux/files/usr/bin/bash
while true; do
 clear
 echo "=== MENU DE UTILIDADES ==="
 echo "1) Fecha y hora"
 echo "2) Espacio disponible"
 echo "3) Arquitectura"
 echo "4) Probar HTTPS"
 echo "0) Salir"
 read -r -p "Opción: " choice
 case "$choice" in
  1) date ;;
  2) df -h "$HOME" ;;
  3) uname -m ;;
  4) if command -v curl >/dev/null 2>&1; then curl -Is --connect-timeout 4 --max-time 7 https://example.com >/dev/null && echo "HTTPS OK" || echo "Sin conexión confirmada"; else echo "Instala curl"; fi ;;
  0) exit 0 ;;
  *) echo "Opción no válida" ;;
 esac
 read -r -p "Enter para continuar..."
done
