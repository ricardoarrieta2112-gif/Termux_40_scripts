#!/data/data/com.termux/files/usr/bin/bash
echo "Hora local:"; date
if command -v curl >/dev/null 2>&1; then
  echo "Hora indicada por cabecera HTTP (si está disponible):"
  curl -sI --max-time 8 https://example.com | grep -i '^date:' || echo "No disponible"
fi
