#!/data/data/com.termux/files/usr/bin/bash
echo "=== FECHA Y HORA ==="
date
echo "Zona horaria: ${TZ:-configuración del sistema}"
