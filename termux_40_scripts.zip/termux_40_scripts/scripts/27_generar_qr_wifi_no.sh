#!/data/data/com.termux/files/usr/bin/bash
echo "Utilidad segura: muestra cómo instalar una herramienta QR."
echo "No solicita ni almacena contraseñas Wi-Fi."
echo "Para crear QR de texto puedes instalar: pkg install qrencode"
if command -v qrencode >/dev/null 2>&1; then
  read -r -p "Texto no sensible para convertir en QR: " value
  [ -n "$value" ] && printf '%s' "$value" | qrencode -t ANSIUTF8
else echo "qrencode aún no está instalado."; fi
