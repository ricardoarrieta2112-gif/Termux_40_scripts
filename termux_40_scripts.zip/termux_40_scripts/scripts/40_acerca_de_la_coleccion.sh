#!/data/data/com.termux/files/usr/bin/bash
echo "===================================="
echo " COLECCION DE 40 SCRIPTS PARA TERMUX"
echo "===================================="
echo "Entorno: Termux en Android"
echo "Objetivo: utilidades educativas y de diagnóstico"
echo "Los scripts no necesitan root."
echo
echo "Ubicación sugerida: ~/scripts"
echo "Ejecuta uno con: bash ~/scripts/01_diagnostico.sh"
echo
echo "Revisa cada script antes de ejecutarlo y no ejecutes scripts de fuentes desconocidas."
