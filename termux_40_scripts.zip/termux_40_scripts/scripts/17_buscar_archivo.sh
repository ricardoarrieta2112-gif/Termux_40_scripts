#!/data/data/com.termux/files/usr/bin/bash
read -r -p "Nombre o patrón a buscar dentro de HOME: " pattern
[ -n "$pattern" ] || { echo "Patrón vacío."; exit 1; }
find "$HOME" -iname "*$pattern*" -print 2>/dev/null | head -200
