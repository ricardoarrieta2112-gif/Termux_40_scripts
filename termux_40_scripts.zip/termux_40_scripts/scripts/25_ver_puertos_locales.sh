#!/data/data/com.termux/files/usr/bin/bash
echo "=== SOCKETS LOCALES VISIBLES ==="
if command -v ss >/dev/null 2>&1; then ss -lntu 2>/dev/null || ss -ntu
else echo "Instala iproute2: pkg install iproute2"; fi
echo "Solo se muestran sockets que Android permita consultar."
