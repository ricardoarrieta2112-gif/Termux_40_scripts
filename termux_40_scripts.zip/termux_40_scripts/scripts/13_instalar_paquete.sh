#!/data/data/com.termux/files/usr/bin/bash
read -r -p "Nombre exacto del paquete que quieres instalar: " package
[ -n "$package" ] || { echo "Cancelado: nombre vacío."; exit 1; }
echo "Se solicitará a pkg instalar: $package"
read -r -p "¿Continuar? [s/N] " answer
case "$answer" in s|S|si|SI|sí|Sí) pkg install "$package" ;; *) echo "Cancelado." ;; esac
