#!/data/data/com.termux/files/usr/bin/bash
read -r -p "Nombre o parte del paquete: " query
[ -n "$query" ] || { echo "No escribiste nada."; exit 1; }
pkg search "$query"
