#!/data/data/com.termux/files/usr/bin/bash
echo "Servidor HTTP local solo en este dispositivo (127.0.0.1:8000)."
echo "Pulsa Ctrl+C para detenerlo."
command -v python >/dev/null 2>&1 || { echo "Instala Python: pkg install python"; exit 1; }
cd "$HOME" || exit 1
python -m http.server 8000 --bind 127.0.0.1
