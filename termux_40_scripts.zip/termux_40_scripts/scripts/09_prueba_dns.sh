#!/data/data/com.termux/files/usr/bin/bash
set -u
host="${1:-example.com}"
echo "=== PRUEBA DNS: $host ==="
if command -v getent >/dev/null 2>&1; then getent hosts "$host" || echo "No se pudo resolver $host"
elif command -v ping >/dev/null 2>&1; then ping -c 1 -W 3 "$host" 2>&1 | head -8
else echo "Instala dnsutils o inetutils para más herramientas."; fi
