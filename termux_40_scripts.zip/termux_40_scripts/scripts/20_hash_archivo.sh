#!/data/data/com.termux/files/usr/bin/bash
read -r -p "Ruta del archivo: " file
[ -f "$file" ] || { echo "Archivo no encontrado."; exit 1; }
sha256sum "$file"
