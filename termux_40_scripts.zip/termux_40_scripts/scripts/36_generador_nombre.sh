#!/data/data/com.termux/files/usr/bin/bash
adjectives=(azul rapido lunar pixel noble curioso)
nouns=(linux cometa dragon terminal zorro planeta)
a=${adjectives[$((RANDOM % ${#adjectives[@]}))]}
n=${nouns[$((RANDOM % ${#nouns[@]}))]}
echo "${a}_${n}_$((RANDOM % 900 + 100))"
