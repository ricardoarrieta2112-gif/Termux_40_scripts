#!/data/data/com.termux/files/usr/bin/bash
echo "=== BATERIA ANDROID ==="
if command -v termux-battery-status >/dev/null 2>&1; then
  termux-battery-status
else
  echo "La API de batería no está instalada."
  echo "Instala Termux:API desde la misma fuente que Termux y ejecuta:"
  echo "  pkg install termux-api"
fi
