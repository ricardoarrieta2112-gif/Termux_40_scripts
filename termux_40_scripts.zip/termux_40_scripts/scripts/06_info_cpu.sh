#!/data/data/com.termux/files/usr/bin/bash
echo "=== CPU / ARQUITECTURA ==="
uname -a
if [ -r /proc/cpuinfo ]; then
  grep -m 1 -E '^(Hardware|model name|Processor|CPU architecture)' /proc/cpuinfo || true
fi
