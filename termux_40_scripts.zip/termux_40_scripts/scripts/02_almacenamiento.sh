#!/data/data/com.termux/files/usr/bin/bash
set -u
echo "=== ALMACENAMIENTO ==="
df -h "$HOME"
echo
echo "Carpetas principales de HOME (tamaño aproximado):"
du -sh "$HOME"/* "$HOME"/.[!.]* 2>/dev/null | sort -h | tail -20 || true
