#!/data/data/com.termux/files/usr/bin/bash
set -u
out="$HOME/backup_home_$(date +%Y%m%d_%H%M%S).tar.gz"
echo "Creará una copia comprimida de HOME en:"
echo "$out"
echo "Puede ocupar bastante espacio."
read -r -p "¿Continuar? [s/N] " answer
case "$answer" in s|S|si|SI|sí|Sí) tar -czf "$out" -C "$(dirname "$HOME")" "$(basename "$HOME")" && echo "Copia creada." ;; *) echo "Cancelado." ;; esac
