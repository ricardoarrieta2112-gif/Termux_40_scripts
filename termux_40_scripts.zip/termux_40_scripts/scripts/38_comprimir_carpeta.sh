#!/data/data/com.termux/files/usr/bin/bash
read -r -p "Ruta de carpeta a comprimir: " folder
[ -d "$folder" ] || { echo "La carpeta no existe."; exit 1; }
read -r -p "Nombre del archivo .tar.gz (se guardará en HOME): " name
case "$name" in ""|*/*|.|..) echo "Nombre no válido."; exit 1 ;; esac
case "$name" in *.tar.gz) ;; *) name="$name.tar.gz" ;; esac
out="$HOME/$name"
[ ! -e "$out" ] || { echo "Ya existe $out; no se sobrescribirá."; exit 1; }
tar -czf "$out" -C "$(dirname "$folder")" "$(basename "$folder")" && echo "Creado: $out"
