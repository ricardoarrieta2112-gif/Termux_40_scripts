#!/data/data/com.termux/files/usr/bin/bash
echo "=== PAQUETES INSTALADOS ==="
if command -v dpkg-query >/dev/null 2>&1; then dpkg-query -W -f='${binary:Package}\n' | sort
else pkg list-installed; fi
