#!/data/data/com.termux/files/usr/bin/bash
read -r -p "URL HTTPS del archivo: " url
case "$url" in https://*) ;; *) echo "Por seguridad, usa una URL que empiece por https://"; exit 1 ;; esac
command -v curl >/dev/null 2>&1 || { echo "Instala curl: pkg install curl"; exit 1; }
read -r -p "Nombre del archivo de salida: " name
case "$name" in ""|*/*|.|..) echo "Nombre no válido."; exit 1 ;; esac
curl -fL --connect-timeout 10 --max-time 300 --output "$HOME/$name" "$url" && echo "Guardado en $HOME/$name"
