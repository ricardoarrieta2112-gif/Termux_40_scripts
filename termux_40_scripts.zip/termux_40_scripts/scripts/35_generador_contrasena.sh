#!/data/data/com.termux/files/usr/bin/bash
read -r -p "Longitud (12-64): " length
case "$length" in ''|*[!0-9]*) echo "Introduce un entero."; exit 1 ;; esac
[ "$length" -ge 12 ] && [ "$length" -le 64 ] || { echo "Usa una longitud de 12 a 64."; exit 1; }
if [ -r /dev/urandom ]; then
  LC_ALL=C tr -dc 'A-Za-z0-9_@%+=-' < /dev/urandom | head -c "$length"
  echo
else echo "Generador aleatorio no disponible."; exit 1; fi
echo "No compartas la contraseña ni la guardes en archivos públicos."
