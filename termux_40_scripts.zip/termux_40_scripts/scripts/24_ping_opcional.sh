#!/data/data/com.termux/files/usr/bin/bash
read -r -p "Host o dominio a probar: " host
[ -n "$host" ] || exit 1
if command -v ping >/dev/null 2>&1; then ping -c 4 -W 3 "$host"; else echo "Instala inetutils: pkg install inetutils"; fi
