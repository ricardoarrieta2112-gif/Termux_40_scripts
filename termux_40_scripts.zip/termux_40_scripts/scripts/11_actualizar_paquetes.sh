#!/data/data/com.termux/files/usr/bin/bash
echo "Se actualizarán los paquetes de Termux."
read -r -p "¿Continuar? [s/N] " answer
case "$answer" in s|S|si|SI|sí|Sí) pkg update && pkg upgrade ;; *) echo "Cancelado." ;; esac
