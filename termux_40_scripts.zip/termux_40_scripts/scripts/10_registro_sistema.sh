#!/data/data/com.termux/files/usr/bin/bash
set -u
out="$HOME/termux_diagnostico_$(date +%Y%m%d_%H%M%S).txt"
{
 echo "Diagnóstico Termux - $(date)"
 echo "Arquitectura: $(uname -m)"
 echo "Kernel: $(uname -sr)"
 echo
 df -h "$HOME"
 echo
 grep -E '^(MemTotal|MemAvailable|SwapTotal|SwapFree):' /proc/meminfo 2>/dev/null || true
} > "$out"
echo "Informe guardado en: $out"
