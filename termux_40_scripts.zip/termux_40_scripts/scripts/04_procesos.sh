#!/data/data/com.termux/files/usr/bin/bash
echo "=== PROCESOS VISIBLES ==="
ps -ef 2>/dev/null | head -40 || ps aux | head -40
echo
echo "Nota: Android limita qué procesos puede ver Termux."
